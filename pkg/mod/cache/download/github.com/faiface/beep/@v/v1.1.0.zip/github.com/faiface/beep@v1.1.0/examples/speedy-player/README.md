# Speedy Player

A simple MP3 player that allows changing the **playback speed**.

![Screenshot](screenshot.png)
