// Package wav implements audio data decoding and encoding in WAVE format.
package wav
