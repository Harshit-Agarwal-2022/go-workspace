# Code for the [tutorials](https://github.com/faiface/beep/wiki)

Here's the code for all the tutorials from the [Wiki](https://github.com/faiface/beep/wiki/Hello,-Beep!).

All the music is downloaded from [Free Music Archive](https://freemusicarchive.org) and [Free Sound Effects.com](https://www.freesoundeffects.com/).
